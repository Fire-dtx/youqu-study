#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从登记表 + 用例库生成 .automation/manifest.json（待过检用例清单）。

用法: /usr/bin/python3 .automation/gen_manifest.py
"""
import json
import os
import re
import openpyxl

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
AUTO = os.path.join(ROOT, ".automation")
REG = "/home/ut000635@uos/.dsh/attachments/v1/files/ef/efb1895d29f389c061754caa16d859838ad03a8263e9efd2b7e2c616644ae8ff/V20电脑管家自动化测试单用例过检登记表.xlsx"
ALL = "/home/ut000635@uos/.dsh/attachments/v1/files/6b/6bf77cc54e802228e530e33897d249673bd8b2cbc28c871b7022272594136a99/电脑管家-所有用例.xlsx"
CASE_DIR = os.path.join(ROOT, "apps/autotest_my_app/case")


def norm(v):
    if v is None:
        return ""
    s = str(v).replace("\r\n", "\n").strip()
    s = s.replace("&#039;", "'").replace("&quot;", '"').replace("&amp;", "&")
    s = s.replace("&lt;", "<").replace("&gt;", ">")
    return s


def main():
    reg = openpyxl.load_workbook(REG, data_only=True)["Sheet1"]
    detail = {}
    ws = openpyxl.load_workbook(ALL, data_only=True)["用例"]
    for row in ws.iter_rows(min_row=2, values_only=True):
        if not row or not row[0]:
            continue
        detail[str(row[0]).strip()] = {
            "title": norm(row[4]),
            "module": norm(row[2]),
            "pre": norm(row[5]),
            "steps": norm(row[6]),
            "expect": norm(row[7]),
            "priority": norm(row[10]),
        }

    files = {}
    for name in os.listdir(CASE_DIR):
        m = re.match(r"^(\d+)_(.+)\.py$", name)
        if m:
            files[m.group(1)] = name

    cases = []
    stats = {"marked": 0, "empty": 0, "no_file": 0, "no_detail": 0, "template": 0}
    for r in range(1, reg.max_row + 1):
        name = norm(reg.cell(r, 1).value)
        status = norm(reg.cell(r, 2).value)
        if not name or name == "用例":
            continue
        if status:
            stats["marked"] += 1
            continue
        stats["empty"] += 1
        m = re.match(r"^apps\.autotest_my_app\.case\.(\d+)_", name)
        if not m:
            stats["template"] += 1
            continue
        cid = m.group(1)
        mm = re.search(r"#(test_mycase_\d+)", name)
        method = mm.group(1) if mm else ""
        if cid not in files:
            stats["no_file"] += 1
            continue
        d = detail.get(cid)
        if not d:
            stats["no_detail"] += 1
            d = {"title": "", "module": "", "pre": "", "steps": "", "expect": "", "priority": ""}
        fname = files[cid]
        cases.append({
            "id": cid,
            "method": method,
            "title": fname[len(cid) + 1:-3],
            "file": "apps/autotest_my_app/case/" + fname,
            "excelRow": r,
            "module": d["module"],
            "pre": d["pre"],
            "steps": d["steps"],
            "expect": d["expect"],
            "priority": d["priority"],
            "detailTitle": d["title"],
        })

    manifest = {
        "version": 1,
        "note": "登记表中状态为空、需要过检的用例清单（按登记表行号排序）",
        "caseCount": len(cases),
        "stats": stats,
        "cases": cases,
    }
    with open(os.path.join(AUTO, "manifest.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=1)

    ledger_path = os.path.join(AUTO, "ledger.json")
    ledger = {"version": 1, "cases": {}}
    if os.path.exists(ledger_path):
        with open(ledger_path, encoding="utf-8") as f:
            ledger = json.load(f)
    for c in cases:
        ledger["cases"].setdefault(c["id"], {
            "status": "pending",
            "attempts": 0,
            "method": c["method"],
            "updatedAt": "",
            "note": "",
        })
    with open(ledger_path, "w", encoding="utf-8") as f:
        json.dump(ledger, f, ensure_ascii=False, indent=1)

    print(json.dumps({"cases": len(cases), "stats": stats}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()
