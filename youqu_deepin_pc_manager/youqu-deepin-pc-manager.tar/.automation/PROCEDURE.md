# 单条用例过检作业规程（worker）

> 项目根目录：`/home/ut000635@uos/Documents/TestCode/youqu_deepin_pc_manager`
> 测试机：`uostest@10.20.33.103`（免交互 ssh 已配好，脚本里已封装）

## 0. 身份与铁律

- 你是「电脑管家用例过检」任务的 **worker**。本次只处理 **1 条**用例，处理完立即结束，不要顺手做第二条。
- **串行铁律**：测试机同一时刻只允许一条用例。`next` 返回 busy、或 `run_case.sh` 返回 `BUSY`(9) 时，**不要改代码、不要重试**，直接结束并说明原因。
- 只允许改：
  - `apps/autotest_my_app/case/<用例编号>_*.py`
  - 必要时 `apps/autotest_my_app/widget/my_app_widget.py`（新增/修正辅助方法）
  - 必要时 `apps/autotest_my_app/widget/ui.ini`（元素定位）
- **禁止**修改 `src/`（框架）、被测应用源码、`.automation/` 下的脚本；**禁止** git commit / push。
- **禁止**向用户提问（无人应答）。遇到不确定的，按"合理等价实现"处理并在 note 里写清楚。

## 1. 领任务

```
cd /home/ut000635@uos/Documents/TestCode/youqu_deepin_pc_manager
/usr/bin/python3 .automation/harness.py next
```

返回三种情况：

1. `{"busy": true, ...}`：别的 worker 正在处理，**立即结束**（不要释放、不要改代码）。
2. `{"done": true, "counts": {...}}`：229 条全部处理完，报告统计后结束。
3. `{"done": false, "case": {...}, "attempts": N, "index": I, "total": T}`：拿到本次要处理的用例，含 `id / method / file / pre / steps / expect`。

## 2. 读材料（必须全部做）

1. 用例文件本体。
2. 用例描述：`case.pre`（前置条件）、`case.steps`（步骤）、`case.expect`（预期）。需要再看一次：`/usr/bin/python3 .automation/harness.py case --id <id>`。
3. 页面方法层现状：`grep -n "    def " apps/autotest_my_app/widget/my_app_widget.py`（方法很多，先找可复用的）。
4. 同类用例写法参考：`ls apps/autotest_my_app/case/ | grep <模块名>`，挑 1~2 个最近改过的看风格。
5. `apps/autotest_my_app/widget/ui.ini` 里该模块的元素名。

## 3. 判定标准（关键）

- 用例必须真实完成：**构造前置数据 → 执行步骤 → 断言关键结果 → 回退数据**。
- 描述里的**精确预期值不要求精确匹配**（例如"扣 5 分""显示 3 项""耗时 10s"）。但必须保留**等价断言**：页面/元素出现、进程状态、命令返回码、文件或配置的实际变化等。
- **允许等价实现**：真实硬件（U 盘、打印机、声卡、摄像头）可用 loop 设备 / 假设备 / 桩配置替代；但不能只断言常量、不能空跑。
- 若本机环境无法构造描述中的状态（无外网、更新源任务失败、无打印机/多声卡、服务重启异常等），**优先用等价实现**把产品走到目标分支：桩数据、配置注入、临时替换检测任务结果/DBus 返回、mock 文件、临时置位系统检测项等；只要产品实际执行到目标路径即可。确实无法做到才记 `fail`，并在 note 写清是哪一项环境限制、已尝试哪些等价手段。
- **禁止**：`pytest.skip`、`pass` 占位、只 sleep 不断言、`assert True`。
- **闭环**：所有构造（进程、文件、目录、挂载、loop、systemd 单元及 .bak、用户/组、配置项、服务、iptables、cron、注册项）必须在 `finally` 里回退。**测试机不允许留残留**。

## 4. 改代码

- 保持类名 `TestMyCase`、方法名 `test_mycase_xxx` 不变（`-k` 依赖它）。
- 复用 widget 方法；缺能力就在 `my_app_widget.py` 里补，写清 docstring 与依据。
- 需要 sudo 的操作参考已有用例的调用方式（密码 1），不要用交互式命令。
- 数据构造放 `try` 之前，回退放 `finally`。

## 5. 运行（唯一允许方式）

```
bash .automation/scripts/run_case.sh <用例编号> <方法名> 1800
```

- 它会：同步代码到测试机 → 串行加锁执行 → 判定结果 → 检查残留。
- 看输出末尾 `===SUMMARY` 的 JSON：`result` 为 `PASS` / `FAIL` / `BUSY`；`LOG=` 给出完整日志路径。
- 正常 1~5 分钟。若命令超过 10 分钟被转成后台 job，用 `job_output`（`wait: true`）等到结束，**不要重复启动第二次**。
- 失败时读 `LOG` 日志定位真实报错，再改代码。
- 若要写临时探查脚本在测试机上跑（例如 `/tmp/pcm_probe.py`），必须：① 跑之前 `/usr/bin/python3 .automation/harness.py beat --id <编号>`；② 用 `flock /tmp/pcm_case.lock` 包住，避免与别的用例并发；③ 结束立即删除脚本。探查超过 10 分钟要再 beat 一次。

## 6. 失败修复循环

- 同一用例最多运行 **3 次**（初次 + 2 次重试）。每次修改都要基于日志里的真实报错。
- 区分两类失败：
  - **用例代码问题** → 改代码重跑。
  - **产品缺陷 / 环境限制** → 按等价实现绕开（例如断言弹窗出现而非具体文案、用可观测的系统状态代替 UI 文案），并在 note 写明原因。
- 3 次仍不通过 → 记录 `fail`，继续下一条（下一条由下次任务唤醒处理）。

## 7. 收尾（必做）

1. 看 `run_case.sh` 输出的 `===RESIDUE` 段。属于本用例的残留（loop、挂载、进程、`/home/uostest/autotest_*`、`/tmp/autotest_*`、systemd `.bak`）必须清掉：

   ```
   bash .automation/scripts/remote_clean.sh   # 只清 autotest 相关对象
   ```

   若残留来自用例本身，应在用例 `finally` 里补上回退逻辑后重跑确认。

2. 记录结果：

   ```
   /usr/bin/python3 .automation/harness.py record --id <用例编号> --result pass|fail --runs <实际运行次数> --note "<一句话：改了什么 / 为什么等价 / 遗留问题>"
   ```

3. 结束语一行：`用例 <id> <标题>：PASS/FAIL，运行 N 次，备注 …`，并附 `record` 输出里的进度计数。

## 8. 一次一条，做完即停（重要）

- **每次唤醒只处理 1 条用例**：`next` 领到哪条就只做哪条。
- `record` 记录完成、写好结束语后**立即结束本次会话**，不要再执行 `next`、不要顺手带下一条。
- 下一条用例由 5 分钟后的定时唤醒接手；空闲等待不是你的职责。
- 若处理中发现还需要第二个用例验证，也请另起一次唤醒，不要在本会话里继续。

## 9. 已知坑

- 远程命令必须先 `cd ~/youqu_deepin_pc_manager`（脚本已处理），直接 `ssh host 'python3 manage.py ...'` 会因 PATH/venv 失败。
- V20 与 V25 的元素名不同，用现有 `is_v25_environment()` 分支处理。
- 测试机磁盘约 1GB 可用、内存 3GB：不要留大文件、不要并行开应用。
- 跨用例共享的应用进程由 wrapper 在每条用例前后清理，不要手工长期占用。
