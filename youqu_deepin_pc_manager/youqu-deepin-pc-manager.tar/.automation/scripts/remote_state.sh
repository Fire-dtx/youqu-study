#!/bin/bash
# 测试机忙碌状态（只读）
echo "== pytest processes"
pgrep -af "manage.py run" | grep -v pgrep | head -5
echo "== lock"
if flock -n /tmp/pcm_case.lock -c 'true' 2>/dev/null; then echo "LOCK_FREE"; else echo "LOCK_HELD"; fi
echo "== latest report"
f=$(ls -t "$HOME/youqu_deepin_pc_manager/report/json"/result_autotest_my_app_*.json 2>/dev/null | head -1)
if [ -n "$f" ]; then echo "$f"; stat -c '%y' "$f"; fi
echo "== latest log tail"
l=$(ls -t "$HOME/youqu_deepin_pc_manager/report/logs"/*.log 2>/dev/null | head -1)
if [ -n "$l" ]; then echo "$l"; tail -3 "$l"; fi
