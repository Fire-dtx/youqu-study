#!/bin/bash
# 测试机残留检查（只读）
echo "== processes"
pgrep -af "deepin-pc-manager" | grep -v pgrep | head -10
echo "== loops(autotest)"
losetup -a 2>/dev/null | grep -i autotest | head -10
echo "== mounts(autotest)"
mount 2>/dev/null | grep -Ei "autotest" | head -10
echo "== media"
ls -d /media/*/autotest* /media/autotest* 2>/dev/null | head -10
echo "== home"
ls -d "$HOME"/autotest* 2>/dev/null | head -10
echo "== tmp"
ls -d /tmp/autotest* /tmp/pcm_* 2>/dev/null | head -10
echo "== systemd bak"
ls /usr/lib/systemd/system/*.bak 2>/dev/null | head -10
