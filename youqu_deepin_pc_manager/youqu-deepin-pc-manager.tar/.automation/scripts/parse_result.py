#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""解析 manage.py 运行日志，判定单条用例结果。"""
import json
import re
import sys


def main(path):
    with open(path, encoding="utf-8", errors="replace") as f:
        text = f.read()
    m = re.search(r"^===RUN_RC=(\d+)$", text, re.M)
    rc = int(m.group(1)) if m else None
    body = None
    start = text.find("===LATEST_JSON=")
    if start >= 0:
        tail = text[start:].split("\n", 1)
        if len(tail) > 1:
            chunk = tail[1]
            try:
                body = json.loads(chunk[chunk.find("{"):chunk.rfind("}") + 1])
            except Exception:
                body = None
    passed = failed = total = 0
    if isinstance(body, dict):
        for item in body.get("items", []):
            st = item.get("statistic", {})
            passed += int(st.get("passed", 0))
            failed += int(st.get("failed", 0)) + int(st.get("broken", 0))
            total += int(st.get("total", 0))
    busy = "REMOTE_BUSY" in text
    if busy or rc == 9:
        result = "BUSY"
    elif failed > 0 or (rc not in (0, None)):
        result = "FAIL"
    elif passed > 0:
        result = "PASS"
    else:
        result = "UNKNOWN"
    print(json.dumps({
        "result": result,
        "runRc": rc,
        "passed": passed,
        "failed": failed,
        "total": total,
        "hasReport": body is not None,
    }, ensure_ascii=False))
    return 0 if result == "PASS" else (9 if result == "BUSY" else 1)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
