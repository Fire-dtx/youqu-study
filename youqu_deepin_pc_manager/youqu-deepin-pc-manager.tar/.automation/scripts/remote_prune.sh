#!/bin/bash
# 测试机报告裁剪，控制磁盘占用（保留最近 30 份日志/结果，删除旧录屏与 allure 备份）
cd "$HOME/youqu_deepin_pc_manager" 2>/dev/null || exit 0
ls -t report/logs/*.log 2>/dev/null | tail -n +31 | xargs -r rm -f
ls -t report/json/result_*.json 2>/dev/null | tail -n +31 | xargs -r rm -f
rm -rf report/allure_back 2>/dev/null
find report/record -type f -mtime +2 -delete 2>/dev/null
du -sh report 2>/dev/null
df -h / | tail -1
