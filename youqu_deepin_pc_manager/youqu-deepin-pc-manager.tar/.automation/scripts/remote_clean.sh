#!/bin/bash
# 清理测试机上测试残留（仅限 autotest 相关对象）
pkill -f "deepin-pc-manager-launch" 2>/dev/null
pkill -f "/usr/bin/deepin-pc-manager" 2>/dev/null

# sudo 密码统一取项目配置 setting/globalconfig.ini（可用 PCM_SSH_PASS/PCM_CONF 覆盖）
if [ -z "${PCM_SSH_PASS}" ]; then
  _PCM_CONF="${PCM_CONF:-${PWD}/setting/globalconfig.ini}"
  PCM_SSH_PASS="$(grep -E '^PASSWORD[[:space:]]*=' "${_PCM_CONF}" 2>/dev/null \
    | grep -v CLIENT_PASSWORD | tail -n1 | cut -d '=' -f2 | tr -d '[:space:]')"
fi
[ -n "${PCM_SSH_PASS}" ] || {
  echo "PCM_SSH_PASS 未设置, 且 ${_PCM_CONF:-$PWD/setting/globalconfig.ini} 中无 PASSWORD" >&2
  exit 1
}

SUDO() { printf '%s\n' "${PCM_SSH_PASS}" | sudo -S -p '' "$@" 2>/dev/null; }

mount 2>/dev/null | grep -Ei "autotest" | awk '{print $3}' | while read -r mp; do
  [ -n "$mp" ] && SUDO umount -l "$mp"
done
losetup -a 2>/dev/null | grep -i autotest | cut -d: -f1 | while read -r dev; do
  [ -n "$dev" ] && SUDO losetup -d "$dev"
done
rm -rf "$HOME"/autotest_* /tmp/autotest_* 2>/dev/null
echo "CLEAN_DONE"
