#!/bin/bash
# 运行单条用例：同步代码 -> 远程串行执行 -> 判定结果 -> 残留检查
# 用法: bash .automation/scripts/run_case.sh <case_id> <method> [timeout]
set -uo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/env.sh"

CID="${1:?case id}"
METHOD="${2:?method}"
TIMEOUT="${3:-1800}"
TS=$(date +%Y%m%d_%H%M%S)
LOG="$AUTO_ROOT/logs/${CID}_${METHOD}_${TS}.log"
mkdir -p "$AUTO_ROOT/logs"

/usr/bin/python3 "$AUTO_ROOT/harness.py" beat --id "$CID" >/dev/null 2>&1

echo "===SYNC"
echo "SYNC_START" >> "$LOG"
if ! bash "$AUTO_ROOT/scripts/sync_to_test.sh" >> "$LOG" 2>&1; then
  tail -n 20 "$LOG"
  echo "RESULT=SYNC_FAILED"
  exit 2
fi

/usr/bin/python3 "$AUTO_ROOT/harness.py" beat --id "$CID" >/dev/null 2>&1

echo "===RUN $METHOD timeout=${TIMEOUT}s"
ssh_cmd "bash -s -- $METHOD $TIMEOUT" < "$AUTO_ROOT/scripts/remote_run.sh" >> "$LOG" 2>&1
SSH_RC=$?

echo "===RESIDUE"
ssh_cmd "bash -s" < "$AUTO_ROOT/scripts/remote_check.sh" >> "$LOG" 2>&1
ssh_cmd "bash -s" < "$AUTO_ROOT/scripts/remote_prune.sh" >> "$LOG" 2>&1

tail -n 60 "$LOG"
echo
echo "===SUMMARY"
/usr/bin/python3 "$AUTO_ROOT/scripts/parse_result.py" "$LOG"
PARSED_RC=$?
echo "LOG=$LOG"
echo "SSH_RC=$SSH_RC"
if [ "$SSH_RC" -eq 255 ]; then
  echo "RESULT=SSH_FAILED"
  exit 2
fi
exit $PARSED_RC
