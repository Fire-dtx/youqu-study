#!/bin/bash
# 在测试机上串行执行一条用例：flock 保证同一时刻只有一条；超时保护；结束后清理残留进程
set -uo pipefail
METHOD="${1:?method required}"
TIMEOUT="${2:-1500}"
cd "$HOME/youqu_deepin_pc_manager" || { echo "NO_PROJECT_DIR"; exit 2; }

exec 9>/tmp/pcm_case.lock
if ! flock -n 9; then
  echo "REMOTE_BUSY"
  exit 9
fi

pkill -f "deepin-pc-manager-launch" 2>/dev/null
pkill -f "deepin-pc-manager" 2>/dev/null
sleep 1

export DISPLAY=:0
export QT_ACCESSIBILITY=1
export QT_LINUX_ACCESSIBILITY_ALWAYS_ON=1
export XDG_RUNTIME_DIR=${XDG_RUNTIME_DIR:-/run/user/$(id -u)}

timeout "$TIMEOUT" python3 manage.py run -a apps/autotest_my_app -k "$METHOD"
RC=$?

pkill -f "deepin-pc-manager-launch" 2>/dev/null
pkill -f "deepin-pc-manager" 2>/dev/null

LATEST=$(ls -t report/json/result_autotest_my_app_*.json 2>/dev/null | head -1)
echo
echo "===RUN_RC=$RC"
echo "===LATEST_JSON=$LATEST"
if [ -n "$LATEST" ]; then
  cat "$LATEST"
  echo
fi
exit $RC
