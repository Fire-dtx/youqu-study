#!/bin/bash
# 同步本地代码到测试机（保留测试机 .venv / report / .git）
set -uo pipefail
source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/env.sh"
cd "$PROJECT_ROOT" || exit 2
setsid -w rsync -a --delete \
  --exclude '.venv' --exclude 'report' --exclude '.git' --exclude '__pycache__' \
  --exclude '.pytest_cache' --exclude '.automation' --exclude '.codegraph' \
  --exclude '*.pyc' --exclude '.vscode' \
  -e "ssh $SSH_OPTS" "$PROJECT_ROOT/" "$TEST_HOST:$TEST_DIR/" >/dev/null 2>&1
rc=$?
if [ $rc -ne 0 ]; then
  echo "SYNC_FAILED rc=$rc"
  exit 2
fi
echo "SYNC_OK"
