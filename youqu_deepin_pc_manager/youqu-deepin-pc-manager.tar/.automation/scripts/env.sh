#!/bin/bash
# 公共环境：免交互 ssh/rsync 到测试机
AUTO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROJECT_ROOT="$(cd "$AUTO_ROOT/.." && pwd)"
if [ -z "${PCM_SSH_PASS:-}" ]; then
  PCM_SSH_PASS="$(grep -E '^PASSWORD[[:space:]]*=' "$PROJECT_ROOT/setting/globalconfig.ini" 2>/dev/null \
    | grep -v CLIENT_PASSWORD | tail -n1 | cut -d '=' -f2 | tr -d '[:space:]')"
fi
export PCM_SSH_PASS
export SSH_ASKPASS="$AUTO_ROOT/scripts/askpass.sh"
export SSH_ASKPASS_REQUIRE=force
export SSH_OPTS="-o StrictHostKeyChecking=no -o ConnectTimeout=10 -o ServerAliveInterval=30"
TEST_HOST="${TEST_HOST:-uostest@10.20.33.103}"
TEST_DIR="youqu_deepin_pc_manager"

ssh_cmd() { setsid -w ssh $SSH_OPTS "$TEST_HOST" "$@"; }
ssh_script() { setsid -w ssh $SSH_OPTS "$TEST_HOST" "$@"; }
