#!/bin/sh
printf '%s\n' "${PCM_SSH_PASS}"
