# 监控与恢复规程（monitor）

> 项目根目录：`/home/ut000635@uos/Documents/TestCode/youqu_deepin_pc_manager`
> 你每次被唤醒只做「巡检 + 必要时接手 1 条用例」，做完立即结束，不要连做多条。

## 1. 读状态

```
cd /home/ut000635@uos/Documents/TestCode/youqu_deepin_pc_manager
/usr/bin/python3 .automation/harness.py status
```

得到：`total`、`counts`（pending / in_progress / passed / failed）、`owner`（含 `heartbeatAgeSec`）、`nextPending`。

## 2. 是否已全部完成

若 `counts.pending == 0 且 counts.in_progress == 0`：

1. 汇报最终统计（passed / failed）、失败清单前 10 条（从 `.automation/ledger.json` 里筛 `failed`）。
2. 暂停 worker 定时任务：`schedule_list` 找到标题为「电脑管家用例过检-单条处理」的任务，`schedule_edit` 设 `active: false`。
3. 结束。

## 3. 正常在跑

若 `owner` 存在且 `heartbeatAgeSec < 3600`：一句话说明「用例 <id> 处理中，心跳 Ns」后结束，**不要改代码、不要释放**。

## 4. 心跳超时（核心恢复逻辑）

若 `owner` 存在且 `heartbeatAgeSec >= 3600`：

1. 看测试机是否真的还在跑：

   ```
   ssh 封装在 .automation/scripts/env.sh 里，直接：
   bash -c 'source .automation/scripts/env.sh; ssh_cmd "bash -s" < .automation/scripts/remote_state.sh'
   ```

   输出里看 `pytest processes` 与 `LOCK_HELD`。

2. **仍在跑**（有 `manage.py run` 进程或 LOCK_HELD）：说明只是长用例，`/usr/bin/python3 .automation/harness.py beat --id <owner.caseId>` 续期，结束。

3. **没在跑**（无进程且 LOCK_FREE）：判定为中断，按顺序恢复：

   ```
   /usr/bin/python3 .automation/harness.py release --id <owner.caseId> --reason "心跳超时(<age>s)且远端无进程"
   bash .automation/scripts/remote_clean.sh      # 清理中断残留
   ```

   然后**由你接手这一条**：完整按 `.automation/PROCEDURE.md` 的第 2~7 步执行（读材料 → 改代码 → `run_case.sh` → 必要时修 2 次 → 记录结果）。
   注意：`release` 之后要用 `harness.py next` 重新领取（它会优先取回这条）。

## 5. 长时间静默

若 **没有 owner**，且 `ledger.json` 的 `updatedAt` / `.automation/history.jsonl` 最后一条记录距今超过 **90 分钟**：

- 说明 worker 任务没有正常触发。先 `schedule_list` 检查「电脑管家用例过检-单条处理」是否存在且 active；
- 若缺失或被暂停 → 按文末参数用 `schedule_create` 重建/恢复；
- 然后用 `harness.py next` 接手处理 1 条（按 PROCEDURE 第 2~7 步）。

## 6. 顺带巡检

- 测试机磁盘：`df -h /`，可用低于 300MB 时清理 `~/youqu_deepin_pc_manager/report` 下的旧数据（保留最近 20 份）与 `~/deepin-pc-manager-src`。
- 测试机残留：`bash .automation/scripts/remote_check.sh`，若发现非当前用例的孤儿 loop/挂载/进程，执行 `remote_clean.sh`。
- 不要修改用例代码（除非是在第 4 步接手时）。

## 附：worker 定时任务参数（重建时使用）

- title：`电脑管家用例过检-单条处理`
- target：`new`（每次新建会话，工作目录为项目根目录）
- rrule：
  ```
  DTSTART;TZID=Asia/Shanghai:<下一个整 10 分钟>
  RRULE:FREQ=MINUTELY;INTERVAL=10
  ```
- prompt：
  ```
  【电脑管家用例过检 · 单条处理】你是本任务的 worker。请先完整读取 /home/ut000635@uos/Documents/TestCode/youqu_deepin_pc_manager/.automation/PROCEDURE.md 并严格照做，只处理 1 条用例后结束。第一步执行：cd /home/ut000635@uos/Documents/TestCode/youqu_deepin_pc_manager && /usr/bin/python3 .automation/harness.py next 。若返回 busy 立即结束；若返回 done=true 报告全部完成；否则按规程处理该条并 record 结果。禁止 git commit，禁止向用户提问。
  ```

## 附：monitor 定时任务参数

- title：`电脑管家用例过检-监控恢复`
- target：`new`
- rrule：
  ```
  DTSTART;TZID=Asia/Shanghai:<下一个整 20 分钟 +5 分钟>
  RRULE:FREQ=MINUTELY;INTERVAL=20
  ```
