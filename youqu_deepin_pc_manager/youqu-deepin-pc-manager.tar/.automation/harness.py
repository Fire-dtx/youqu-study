#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""电脑管家用例过检任务台账工具（单条用例串行处理）。

子命令：
  next    [--stale 3600]       领取下一条待过检用例（占用 worker 锁）
  case    --id <id>            打印某条用例的完整信息
  beat    --id <id>            心跳续期
  record  --id <id> --result pass|fail [--note ""] [--runs N]
                               记录结果并释放占用（同时刷新 Excel 副本）
  release --id <id> [--reason] 归还用例（标记回 pending，供监控任务恢复）
  status                       查看进度
  export                       重新生成 Excel 回写副本
"""
import argparse
import fcntl
import json
import os
import sys
import time
from datetime import datetime, timedelta

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
AUTO = os.path.join(ROOT, ".automation")
STATE = os.path.join(AUTO, "state")
OUT = os.path.join(AUTO, "out")
MANIFEST = os.path.join(AUTO, "manifest.json")
LEDGER = os.path.join(AUTO, "ledger.json")
OWNER = os.path.join(STATE, "owner.json")
LOCK = os.path.join(STATE, "harness.lock")
HISTORY = os.path.join(AUTO, "history.jsonl")
REG = "/home/ut000635@uos/.dsh/attachments/v1/files/ef/efb1895d29f389c061754caa16d859838ad03a8263e9efd2b7e2c616644ae8ff/V20电脑管家自动化测试单用例过检登记表.xlsx"


def now():
    return datetime.now().astimezone()


def iso(dt=None):
    return (dt or now()).isoformat(timespec="seconds")


def ensure_dirs():
    for d in (STATE, OUT, os.path.join(AUTO, "logs")):
        if not os.path.isdir(d):
            os.makedirs(d)


def load_json(path, default=None):
    if not os.path.exists(path):
        return default
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def save_json(path, data):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def append_history(rec):
    with open(HISTORY, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


def manifest():
    return load_json(MANIFEST, {"cases": []})


def ledger():
    led = load_json(LEDGER, {"version": 1, "cases": {}})
    led.setdefault("cases", {})
    return led


def owner():
    return load_json(OWNER, None)


def save_owner(data):
    if data is None:
        if os.path.exists(OWNER):
            os.remove(OWNER)
        return
    save_json(OWNER, data)


def counts(led):
    res = {}
    for c in led["cases"].values():
        res[c.get("status", "pending")] = res.get(c.get("status", "pending"), 0) + 1
    return res


def next_pending(man, led):
    for c in man["cases"]:
        if led["cases"].get(c["id"], {}).get("status") == "pending":
            return c
    return None


def cmd_next(args):
    led = ledger()
    man = manifest()
    own = owner()
    if own:
        age = time.time() - float(own.get("lastBeatEpoch", 0))
        if age < args.stale:
            print(json.dumps({
                "busy": True,
                "owner": own.get("caseId"),
                "method": own.get("method"),
                "heartbeatAgeSec": int(age),
                "hint": "已有 worker 在处理该用例，本次不要修改任何代码，直接结束。",
            }, ensure_ascii=False, indent=1))
            return 3
        prev = own.get("caseId")
        if prev and led["cases"].get(prev, {}).get("status") == "in_progress":
            led["cases"][prev]["status"] = "pending"
            led["cases"][prev]["attempts"] = int(led["cases"][prev].get("attempts", 0)) + 1
            led["cases"][prev]["note"] = "心跳超时(%ds)，已由监控回收" % int(age)
            led["cases"][prev]["updatedAt"] = iso()
        append_history({"event": "reclaim", "caseId": prev, "ageSec": int(age), "at": iso()})
        save_owner(None)
        save_json(LEDGER, led)

    case = next_pending(man, led)
    if not case:
        print(json.dumps({"done": True, "counts": counts(led), "total": len(man["cases"])},
                         ensure_ascii=False, indent=1))
        return 0

    entry = led["cases"].setdefault(case["id"], {"status": "pending", "attempts": 0})
    entry["status"] = "in_progress"
    entry["startedAt"] = iso()
    entry["updatedAt"] = iso()
    entry["method"] = case["method"]
    save_json(LEDGER, led)
    save_owner({
        "caseId": case["id"],
        "method": case["method"],
        "startedAt": iso(),
        "startedAtEpoch": time.time(),
        "lastBeat": iso(),
        "lastBeatEpoch": time.time(),
        "pid": os.getpid(),
    })
    append_history({"event": "claim", "caseId": case["id"], "at": iso()})
    print(json.dumps({
        "done": False,
        "case": case,
        "attempts": int(entry.get("attempts", 0)),
        "index": [c["id"] for c in man["cases"]].index(case["id"]) + 1,
        "total": len(man["cases"]),
        "counts": counts(led),
    }, ensure_ascii=False, indent=1))
    return 0


def find_case(cid):
    for c in manifest()["cases"]:
        if c["id"] == cid:
            return c
    return None


def cmd_case(args):
    c = find_case(args.id)
    if not c:
        print(json.dumps({"error": "case not found", "id": args.id}, ensure_ascii=False))
        return 1
    led = ledger()
    out = dict(c)
    out["ledger"] = led["cases"].get(args.id, {})
    print(json.dumps(out, ensure_ascii=False, indent=1))
    return 0


def cmd_beat(args):
    own = owner()
    if not own or own.get("caseId") != args.id:
        print(json.dumps({"ok": False, "reason": "not owner"}, ensure_ascii=False))
        return 1
    own["lastBeat"] = iso()
    own["lastBeatEpoch"] = time.time()
    save_owner(own)
    led = ledger()
    if args.id in led["cases"]:
        led["cases"][args.id]["updatedAt"] = iso()
        save_json(LEDGER, led)
    print(json.dumps({"ok": True, "caseId": args.id, "lastBeat": own["lastBeat"]}, ensure_ascii=False))
    return 0


def cmd_record(args):
    led = ledger()
    entry = led["cases"].setdefault(args.id, {"status": "pending", "attempts": 0})
    entry["status"] = "passed" if args.result == "pass" else "failed"
    entry["finishedAt"] = iso()
    entry["updatedAt"] = iso()
    entry["attempts"] = int(entry.get("attempts", 0)) + max(1, int(args.runs))
    entry["note"] = args.note or ""
    if args.result == "pass" and args.note:
        entry["note"] = args.note
    save_json(LEDGER, led)
    own = owner()
    if own and own.get("caseId") == args.id:
        save_owner(None)
    append_history({"event": "record", "caseId": args.id, "result": args.result,
                    "runs": int(args.runs), "note": args.note or "", "at": iso()})
    export_excel()
    print(json.dumps({"ok": True, "caseId": args.id, "status": entry["status"],
                      "counts": counts(led), "total": len(manifest()["cases"])},
                     ensure_ascii=False, indent=1))
    return 0


def cmd_release(args):
    led = ledger()
    entry = led["cases"].get(args.id)
    if not entry:
        print(json.dumps({"ok": False, "reason": "unknown case"}, ensure_ascii=False))
        return 1
    if entry.get("status") == "in_progress":
        entry["status"] = "pending"
        entry["attempts"] = int(entry.get("attempts", 0)) + 1
        entry["note"] = "监控回收: " + (args.reason or "")
        entry["updatedAt"] = iso()
        save_json(LEDGER, led)
    own = owner()
    if own and own.get("caseId") == args.id:
        save_owner(None)
    append_history({"event": "release", "caseId": args.id, "reason": args.reason or "", "at": iso()})
    print(json.dumps({"ok": True, "caseId": args.id, "status": entry.get("status"),
                      "counts": counts(led)}, ensure_ascii=False, indent=1))
    return 0


def cmd_status(args):
    led = ledger()
    man = manifest()
    nxt = next_pending(man, led)
    own = owner()
    own_view = None
    if own:
        own_view = dict(own)
        own_view["heartbeatAgeSec"] = int(time.time() - float(own.get("lastBeatEpoch", 0)))
    print(json.dumps({
        "total": len(man["cases"]),
        "counts": counts(led),
        "owner": own_view,
        "nextPending": {"id": nxt["id"], "method": nxt["method"], "title": nxt["title"]} if nxt else None,
        "updatedAt": iso(),
    }, ensure_ascii=False, indent=1))
    return 0


def export_excel():
    try:
        import openpyxl
    except ImportError:
        print("WARN: openpyxl 不可用，跳过 Excel 导出（请用 /usr/bin/python3 运行）", file=sys.stderr)
        return None
    led = ledger()
    man = manifest()
    wb = openpyxl.load_workbook(REG)
    ws = wb["Sheet1"]
    row_by_id = {c["id"]: c["excelRow"] for c in man["cases"]}
    n = 0
    for cid, entry in led["cases"].items():
        row = row_by_id.get(cid)
        if not row:
            continue
        st = entry.get("status")
        if st == "passed":
            ws.cell(row, 2).value = "成功"
            n += 1
        elif st == "failed":
            ws.cell(row, 2).value = "失败"
            n += 1
    path = os.path.join(OUT, "V20电脑管家自动化测试单用例过检登记表-回写.xlsx")
    wb.save(path)
    return path


def cmd_requeue_failed(args):
    led = ledger()
    n = 0
    for entry in led["cases"].values():
        if entry.get("status") == "failed":
            if args.note_contains and args.note_contains not in (entry.get("note") or ""):
                continue
            entry["status"] = "pending"
            entry["note"] = args.note
            entry["updatedAt"] = iso()
            n += 1
    save_json(LEDGER, led)
    append_history({"event": "requeue-failed", "count": n, "at": iso()})
    print(json.dumps({"ok": True, "requeued": n, "counts": counts(led)}, ensure_ascii=False, indent=1))
    return 0


def cmd_export(args):
    p = export_excel()
    print(json.dumps({"ok": bool(p), "path": p, "counts": counts(ledger())}, ensure_ascii=False, indent=1))
    return 0


def main():
    ensure_dirs()
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd")

    p = sub.add_parser("next")
    p.add_argument("--stale", type=int, default=3600)
    p.set_defaults(func=cmd_next)

    p = sub.add_parser("case")
    p.add_argument("--id", required=True)
    p.set_defaults(func=cmd_case)

    p = sub.add_parser("beat")
    p.add_argument("--id", required=True)
    p.set_defaults(func=cmd_beat)

    p = sub.add_parser("record")
    p.add_argument("--id", required=True)
    p.add_argument("--result", required=True, choices=["pass", "fail"])
    p.add_argument("--note", default="")
    p.add_argument("--runs", type=int, default=1)
    p.set_defaults(func=cmd_record)

    p = sub.add_parser("release")
    p.add_argument("--id", required=True)
    p.add_argument("--reason", default="")
    p.set_defaults(func=cmd_release)

    p = sub.add_parser("status")
    p.set_defaults(func=cmd_status)

    p = sub.add_parser("export")
    p.set_defaults(func=cmd_export)

    p = sub.add_parser("requeue-failed")
    p.add_argument("--note", default="二轮复检")
    p.add_argument("--note-contains", default="", help="只重置备注包含该关键字的失败用例")
    p.set_defaults(func=cmd_requeue_failed)

    args = ap.parse_args()
    if not getattr(args, "func", None):
        ap.print_help()
        return 2
    with open(LOCK, "w") as lockf:
        fcntl.flock(lockf, fcntl.LOCK_EX)
        return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
